﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PrograAvanzadaSemanaWeb1MVC.Controllers
{
    public class MascotaController : Controller
    {
        public ActionResult Gatos()
        {
            return View();
        }


        public ActionResult Perros()
        {
            return View();
        }
    }
}
