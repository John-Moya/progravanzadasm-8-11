﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PrograAvanzadaSemanaWeb1MVC.Controllers
{
    public class CasaController : Controller
    {
        // GET: CasaController
        public ActionResult CasaEnVenta()
        {
            return View();
        }

        // GET: CasaController
        public ActionResult CasaAlquiler()
        {
            return View();
        }


    }
}
