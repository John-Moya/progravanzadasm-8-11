﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PrograAvanzadaSemanaWeb1MVC.Controllers
{
    public class MueblesController : Controller
    {
        public ActionResult VentaDeMuebles()
        {
            return View();
        }


        public ActionResult AlquilerDeMuebles()
        {
            return View();
        }
    }
}
